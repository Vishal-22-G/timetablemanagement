"""
WSGI config for faculty_load_system project.
"""

import os
from django.core.wsgi import get_wsgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'faculty_load_system.settings')

application = get_wsgi_application()

# For deployment, bind to 0.0.0.0:5000
if __name__ == "__main__":
    from django.core.management import execute_from_command_line
    import sys
    
    if 'runserver' in sys.argv:
        # Add default host and port for development
        if not any('0.0.0.0' in arg for arg in sys.argv):
            sys.argv.append('0.0.0.0:5000')
    
    execute_from_command_line(sys.argv)
