"""
URL configuration for faculty_load_system project.
"""
from django.contrib import admin
from django.urls import path, include
from django.shortcuts import redirect

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', lambda request: redirect('load_management:dashboard')),
    path('load/', include('load_management.urls')),
]
