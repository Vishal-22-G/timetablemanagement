/**
 * Faculty Load Management System - JavaScript Functions
 * Handles dynamic load calculations, form validations, and UI interactions
 */

class LoadCalculator {
    constructor() {
        this.init();
    }

    init() {
        this.bindEvents();
        this.initializeTooltips();
        this.setupFormValidation();
        this.initializeLoadCalculation();
    }

    /**
     * Bind event listeners
     */
    bindEvents() {
        // Course selection change event
        document.addEventListener('change', (e) => {
            if (e.target.id === 'course-select') {
                this.handleCourseSelection(e.target.value);
            }
        });

        // Faculty selection change event
        document.addEventListener('change', (e) => {
            if (e.target.id === 'faculty-select') {
                this.handleFacultySelection(e.target.value);
            }
        });

        // Allocation percentage change events
        document.addEventListener('input', (e) => {
            if (e.target.id === 'theory-percentage' || e.target.id === 'practical-percentage') {
                this.calculateLoadAllocation();
            }
        });

        // Form submission validation
        document.addEventListener('submit', (e) => {
            if (e.target.closest('form[data-validate="load-allocation"]')) {
                this.validateAllocationForm(e);
            }
        });

        // Auto-save functionality
        document.addEventListener('change', (e) => {
            if (e.target.closest('.auto-save')) {
                this.autoSave(e.target);
            }
        });
    }

    /**
     * Initialize Bootstrap tooltips
     */
    initializeTooltips() {
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    }

    /**
     * Setup form validation
     */
    setupFormValidation() {
        const forms = document.querySelectorAll('.needs-validation');
        forms.forEach(form => {
            form.addEventListener('submit', (e) => {
                if (!form.checkValidity()) {
                    e.preventDefault();
                    e.stopPropagation();
                }
                form.classList.add('was-validated');
            });
        });
    }

    /**
     * Initialize load calculation display
     */
    initializeLoadCalculation() {
        const courseSelect = document.getElementById('course-select');
        const facultySelect = document.getElementById('faculty-select');
        
        if (courseSelect && facultySelect) {
            // Initialize with current values
            if (courseSelect.value) {
                this.handleCourseSelection(courseSelect.value);
            }
            if (facultySelect.value) {
                this.handleFacultySelection(facultySelect.value);
            }
            this.calculateLoadAllocation();
        }
    }

    /**
     * Handle course selection and update UI
     */
    async handleCourseSelection(courseId) {
        if (!courseId) {
            this.clearCourseInfo();
            return;
        }

        try {
            const response = await fetch(`/load/api/course/${courseId}/details/`);
            if (!response.ok) throw new Error('Failed to fetch course details');
            
            const courseData = await response.json();
            this.displayCourseInfo(courseData);
            this.calculateLoadAllocation();
        } catch (error) {
            console.error('Error fetching course details:', error);
            this.showAlert('Error loading course details', 'danger');
        }
    }

    /**
     * Handle faculty selection and update UI
     */
    async handleFacultySelection(facultyId) {
        if (!facultyId) {
            this.clearFacultyInfo();
            return;
        }

        try {
            const response = await fetch(`/load/api/faculty/${facultyId}/load/`);
            if (!response.ok) throw new Error('Failed to fetch faculty load');
            
            const facultyData = await response.json();
            this.displayFacultyInfo(facultyData);
            this.calculateLoadAllocation();
        } catch (error) {
            console.error('Error fetching faculty load:', error);
            this.showAlert('Error loading faculty information', 'danger');
        }
    }

    /**
     * Display course information
     */
    displayCourseInfo(courseData) {
        const courseInfoDiv = document.getElementById('course-info');
        if (!courseInfoDiv) return;

        const html = `
            <div class="card border-info">
                <div class="card-header bg-info text-white">
                    <h6 class="mb-0">
                        <i class="fas fa-book me-1"></i>
                        ${courseData.course_code} - ${courseData.course_name}
                    </h6>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <strong>Theory Credits:</strong> ${courseData.theory_credits}
                            <br><small class="text-muted">${courseData.theory_hours_per_week} hours/week</small>
                        </div>
                        <div class="col-md-6">
                            <strong>Practical Credits:</strong> ${courseData.practical_credits}
                            <br><small class="text-muted">${courseData.practical_hours_per_week} hours/week</small>
                        </div>
                    </div>
                    <hr>
                    <div class="text-center">
                        <strong>Total: ${courseData.total_hours_per_week} hours/week</strong>
                    </div>
                </div>
            </div>
        `;
        courseInfoDiv.innerHTML = html;

        // Update allocation percentage inputs max values
        this.updateAllocationInputs(courseData);
    }

    /**
     * Display faculty information
     */
    displayFacultyInfo(facultyData) {
        const facultyInfoDiv = document.getElementById('faculty-info');
        if (!facultyInfoDiv) return;

        const loadPercentage = facultyData.load_percentage;
        let statusClass = 'success';
        let statusIcon = 'check-circle';
        let statusText = 'Normal Load';

        if (loadPercentage >= 100) {
            statusClass = 'danger';
            statusIcon = 'exclamation-triangle';
            statusText = 'Overloaded';
        } else if (loadPercentage >= 80) {
            statusClass = 'warning';
            statusIcon = 'exclamation-circle';
            statusText = 'High Load';
        }

        const html = `
            <div class="card border-${statusClass}">
                <div class="card-header bg-${statusClass} text-white">
                    <h6 class="mb-0">
                        <i class="fas fa-user me-1"></i>
                        ${facultyData.name}
                    </h6>
                </div>
                <div class="card-body">
                    <div class="row text-center">
                        <div class="col-4">
                            <strong>${facultyData.assigned_hours}</strong>
                            <br><small class="text-muted">Assigned</small>
                        </div>
                        <div class="col-4">
                            <strong class="text-${statusClass}">${facultyData.load_left}</strong>
                            <br><small class="text-muted">Available</small>
                        </div>
                        <div class="col-4">
                            <strong>${facultyData.max_load_hours}</strong>
                            <br><small class="text-muted">Maximum</small>
                        </div>
                    </div>
                    <hr>
                    <div class="progress mb-2" style="height: 20px;">
                        <div class="progress-bar bg-${statusClass}" 
                             style="width: ${Math.min(100, loadPercentage)}%">
                            ${loadPercentage.toFixed(1)}%
                        </div>
                    </div>
                    <div class="text-center">
                        <span class="badge bg-${statusClass}">
                            <i class="fas fa-${statusIcon} me-1"></i>${statusText}
                        </span>
                    </div>
                </div>
            </div>
        `;
        facultyInfoDiv.innerHTML = html;
    }

    /**
     * Calculate and display load allocation
     */
    async calculateLoadAllocation() {
        const courseSelect = document.getElementById('course-select');
        const facultySelect = document.getElementById('faculty-select');
        const theoryPercentage = document.getElementById('theory-percentage');
        const practicalPercentage = document.getElementById('practical-percentage');
        const calculationDiv = document.getElementById('load-calculation');

        if (!courseSelect?.value || !facultySelect?.value || !calculationDiv) {
            return;
        }

        const theoryPercent = parseInt(theoryPercentage?.value || 0);
        const practicalPercent = parseInt(practicalPercentage?.value || 0);

        try {
            const response = await fetch('/load/api/calculate-load/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': this.getCSRFToken()
                },
                body: JSON.stringify({
                    course_id: courseSelect.value,
                    faculty_id: facultySelect.value,
                    theory_percentage: theoryPercent,
                    practical_percentage: practicalPercent
                })
            });

            if (!response.ok) throw new Error('Failed to calculate load');
            
            const data = await response.json();
            this.displayLoadCalculation(data);
        } catch (error) {
            console.error('Error calculating load:', error);
            this.showAlert('Error calculating load allocation', 'danger');
        }
    }

    /**
     * Display load calculation results
     */
    displayLoadCalculation(data) {
        const calculationDiv = document.getElementById('load-calculation');
        if (!calculationDiv) return;

        const canAllocate = data.can_allocate;
        const alertClass = canAllocate ? 'success' : 'danger';
        const alertIcon = canAllocate ? 'check-circle' : 'exclamation-triangle';
        const alertText = canAllocate ? 'Allocation possible' : 'Exceeds faculty capacity';

        const html = `
            <div class="alert alert-${alertClass}">
                <div class="row">
                    <div class="col-md-8">
                        <h6>
                            <i class="fas fa-${alertIcon} me-1"></i>
                            Load Calculation
                        </h6>
                        <div class="row">
                            <div class="col-sm-4">
                                <strong>Theory Hours:</strong>
                                <div class="h6 text-primary">${data.theory_hours}</div>
                            </div>
                            <div class="col-sm-4">
                                <strong>Practical Hours:</strong>
                                <div class="h6 text-success">${data.practical_hours}</div>
                            </div>
                            <div class="col-sm-4">
                                <strong>Total Hours:</strong>
                                <div class="h6 text-info">${data.total_hours}</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <h6>Faculty Capacity</h6>
                        <div class="text-center">
                            <div class="h6">${data.faculty_current_load} / ${data.faculty_max_load}</div>
                            <div class="small text-muted">
                                Available: ${data.available_capacity} hrs
                            </div>
                            <div class="badge bg-${alertClass}">
                                <i class="fas fa-${alertIcon} me-1"></i>${alertText}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
        calculationDiv.innerHTML = html;

        // Update submit button state
        this.updateSubmitButton(canAllocate);
    }

    /**
     * Update allocation input constraints
     */
    updateAllocationInputs(courseData) {
        const theoryInput = document.getElementById('theory-percentage');
        const practicalInput = document.getElementById('practical-percentage');

        if (theoryInput) {
            theoryInput.disabled = courseData.theory_credits === 0;
            if (courseData.theory_credits === 0) {
                theoryInput.value = 0;
            }
        }

        if (practicalInput) {
            practicalInput.disabled = courseData.practical_credits === 0;
            if (courseData.practical_credits === 0) {
                practicalInput.value = 0;
            }
        }
    }

    /**
     * Update submit button state
     */
    updateSubmitButton(canAllocate) {
        const submitBtn = document.querySelector('button[type="submit"]');
        if (!submitBtn) return;

        if (canAllocate) {
            submitBtn.disabled = false;
            submitBtn.classList.remove('btn-secondary');
            submitBtn.classList.add('btn-success');
            submitBtn.innerHTML = '<i class="fas fa-save me-1"></i>Save Allocation';
        } else {
            submitBtn.disabled = true;
            submitBtn.classList.remove('btn-success');
            submitBtn.classList.add('btn-secondary');
            submitBtn.innerHTML = '<i class="fas fa-exclamation-triangle me-1"></i>Cannot Allocate';
        }
    }

    /**
     * Validate allocation form
     */
    validateAllocationForm(event) {
        const form = event.target;
        const theoryPercentage = form.querySelector('#theory-percentage');
        const practicalPercentage = form.querySelector('#practical-percentage');
        
        const theoryPercent = parseInt(theoryPercentage?.value || 0);
        const practicalPercent = parseInt(practicalPercentage?.value || 0);

        if (theoryPercent === 0 && practicalPercent === 0) {
            event.preventDefault();
            this.showAlert('At least one allocation percentage must be greater than 0', 'warning');
            return false;
        }

        return true;
    }

    /**
     * Clear course information display
     */
    clearCourseInfo() {
        const courseInfoDiv = document.getElementById('course-info');
        if (courseInfoDiv) {
            courseInfoDiv.innerHTML = '<div class="text-muted text-center py-3">Select a course to view details</div>';
        }
    }

    /**
     * Clear faculty information display
     */
    clearFacultyInfo() {
        const facultyInfoDiv = document.getElementById('faculty-info');
        if (facultyInfoDiv) {
            facultyInfoDiv.innerHTML = '<div class="text-muted text-center py-3">Select faculty to view load status</div>';
        }
    }

    /**
     * Auto-save functionality
     */
    async autoSave(element) {
        const formData = new FormData(element.closest('form'));
        
        try {
            // Show saving indicator
            this.showSavingIndicator();
            
            // Simulate auto-save (implement actual endpoint as needed)
            await new Promise(resolve => setTimeout(resolve, 1000));
            
            this.showAlert('Changes saved automatically', 'success', 2000);
        } catch (error) {
            console.error('Auto-save failed:', error);
            this.showAlert('Auto-save failed', 'warning');
        }
    }

    /**
     * Show saving indicator
     */
    showSavingIndicator() {
        const indicator = document.createElement('div');
        indicator.className = 'position-fixed top-0 end-0 p-3';
        indicator.style.zIndex = '9999';
        indicator.innerHTML = `
            <div class="toast show" role="alert">
                <div class="toast-body">
                    <i class="fas fa-spinner fa-spin me-2"></i>Saving...
                </div>
            </div>
        `;
        document.body.appendChild(indicator);
        
        setTimeout(() => {
            indicator.remove();
        }, 2000);
    }

    /**
     * Show alert message
     */
    showAlert(message, type = 'info', duration = 5000) {
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
        alertDiv.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
        
        alertDiv.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        document.body.appendChild(alertDiv);
        
        // Auto-dismiss
        setTimeout(() => {
            if (alertDiv.parentNode) {
                alertDiv.remove();
            }
        }, duration);
    }

    /**
     * Get CSRF token from cookies
     */
    getCSRFToken() {
        const name = 'csrftoken';
        const cookies = document.cookie.split(';');
        for (let cookie of cookies) {
            const [key, value] = cookie.trim().split('=');
            if (key === name) {
                return decodeURIComponent(value);
            }
        }
        
        // Fallback: try to get from meta tag or hidden input
        const metaToken = document.querySelector('meta[name="csrf-token"]');
        if (metaToken) {
            return metaToken.getAttribute('content');
        }
        
        const hiddenToken = document.querySelector('input[name="csrfmiddlewaretoken"]');
        if (hiddenToken) {
            return hiddenToken.value;
        }
        
        return '';
    }
}

// Utility functions
const LoadUtils = {
    /**
     * Format hours display
     */
    formatHours(hours) {
        return parseFloat(hours).toFixed(2);
    },

    /**
     * Calculate load percentage
     */
    calculateLoadPercentage(assigned, maximum) {
        if (maximum === 0) return 0;
        return Math.min(100, (assigned / maximum) * 100);
    },

    /**
     * Get load status
     */
    getLoadStatus(percentage) {
        if (percentage >= 100) return { class: 'danger', text: 'Overloaded', icon: 'exclamation-triangle' };
        if (percentage >= 80) return { class: 'warning', text: 'High Load', icon: 'exclamation-circle' };
        if (percentage < 50) return { class: 'info', text: 'Under Loaded', icon: 'info-circle' };
        return { class: 'success', text: 'Normal', icon: 'check-circle' };
    },

    /**
     * Debounce function for input events
     */
    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
};

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    new LoadCalculator();
});

// Export for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { LoadCalculator, LoadUtils };
}
