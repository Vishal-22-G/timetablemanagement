from django.apps import AppConfig


class LoadManagementConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'load_management'
    verbose_name = 'Timetable Management'
