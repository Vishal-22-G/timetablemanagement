from django.shortcuts import render, get_object_or_404, redirect
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView, TemplateView
from django.contrib import messages
from django.urls import reverse_lazy
from django.db.models import Q, Sum, Count
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from django.contrib.auth.mixins import LoginRequiredMixin
import json

from .models import Faculty, Course, LoadAllocation
from .forms import (
    FacultyForm, CourseForm, LoadAllocationForm, 
    LoadAllocationFilterForm, BulkLoadAllocationForm
)


class DashboardView(TemplateView):
    """Main dashboard showing overview of faculty loads and allocations."""
    template_name = 'load_management/dashboard.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # Faculty statistics
        faculty_stats = Faculty.objects.all().order_by('name')
        
        # Course statistics
        course_stats = Course.objects.all()
        
        # Load allocation statistics
        allocation_stats = LoadAllocation.objects.all()
        
        # Calculate summary statistics
        total_faculty = faculty_stats.count()
        total_courses = course_stats.count()
        total_allocations = allocation_stats.count()
        
        # Faculty load analysis
        overloaded_faculty = [f for f in faculty_stats if f.total_assigned_hours > f.max_load_hours]
        underloaded_faculty = [f for f in faculty_stats if f.total_assigned_hours < f.max_load_hours * 0.5]
        
        context.update({
            'faculty_list': faculty_stats,
            'course_list': course_stats,
            'allocation_list': allocation_stats,
            'total_faculty': total_faculty,
            'total_courses': total_courses,
            'total_allocations': total_allocations,
            'overloaded_faculty': overloaded_faculty,
            'underloaded_faculty': underloaded_faculty,
            'overloaded_count': len(overloaded_faculty),
            'underloaded_count': len(underloaded_faculty),
        })
        
        return context


class FacultyListView(ListView):
    """List view for faculty members."""
    model = Faculty
    template_name = 'load_management/faculty_list.html'
    context_object_name = 'faculty_list'
    paginate_by = 20
    
    def get_queryset(self):
        queryset = Faculty.objects.all().order_by('name')
        
        # Search functionality
        search_query = self.request.GET.get('search')
        if search_query:
            queryset = queryset.filter(
                Q(name__icontains=search_query) |
                Q(department__icontains=search_query) |
                Q(email__icontains=search_query)
            )
        
        # Department filter
        department = self.request.GET.get('department')
        if department:
            queryset = queryset.filter(department__icontains=department)
        
        return queryset
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['search_query'] = self.request.GET.get('search', '')
        context['department_filter'] = self.request.GET.get('department', '')
        context['departments'] = Faculty.objects.values_list('department', flat=True).distinct().exclude(department__isnull=True).exclude(department='')
        return context


class FacultyDetailView(DetailView):
    """Detail view for a specific faculty member."""
    model = Faculty
    template_name = 'load_management/faculty_detail.html'
    context_object_name = 'faculty'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        faculty = self.get_object()
        
        # Get all allocations for this faculty
        allocations = LoadAllocation.objects.filter(faculty=faculty).select_related('course').order_by('course__course_code', 'division')
        
        # Group allocations by course
        allocations_by_course = {}
        for allocation in allocations:
            course_key = allocation.course.course_code
            if course_key not in allocations_by_course:
                allocations_by_course[course_key] = []
            allocations_by_course[course_key].append(allocation)
        
        context['allocations'] = allocations
        context['allocations_by_course'] = allocations_by_course
        return context


class FacultyCreateView(CreateView):
    """Create view for faculty members."""
    model = Faculty
    form_class = FacultyForm
    template_name = 'load_management/faculty_form.html'
    success_url = reverse_lazy('load_management:faculty_list')
    
    def form_valid(self, form):
        messages.success(self.request, f'Faculty member "{form.instance.name}" created successfully.')
        return super().form_valid(form)


class FacultyUpdateView(UpdateView):
    """Update view for faculty members."""
    model = Faculty
    form_class = FacultyForm
    template_name = 'load_management/faculty_form.html'
    
    def get_success_url(self):
        return reverse_lazy('load_management:faculty_detail', kwargs={'pk': self.object.pk})
    
    def form_valid(self, form):
        messages.success(self.request, f'Faculty member "{form.instance.name}" updated successfully.')
        return super().form_valid(form)


class FacultyDeleteView(DeleteView):
    """Delete view for faculty members."""
    model = Faculty
    template_name = 'load_management/confirm_delete.html'
    success_url = reverse_lazy('load_management:faculty_list')
    
    def delete(self, request, *args, **kwargs):
        faculty = self.get_object()
        messages.success(request, f'Faculty member "{faculty.name}" deleted successfully.')
        return super().delete(request, *args, **kwargs)


class CourseListView(ListView):
    """List view for courses."""
    model = Course
    template_name = 'load_management/course_list.html'
    context_object_name = 'course_list'
    paginate_by = 20
    
    def get_queryset(self):
        queryset = Course.objects.all().order_by('course_code')
        
        # Search functionality
        search_query = self.request.GET.get('search')
        if search_query:
            queryset = queryset.filter(
                Q(course_code__icontains=search_query) |
                Q(course_name__icontains=search_query) |
                Q(semester__icontains=search_query)
            )
        
        return queryset
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['search_query'] = self.request.GET.get('search', '')
        return context


class CourseDetailView(DetailView):
    """Detail view for a specific course."""
    model = Course
    template_name = 'load_management/course_detail.html'
    context_object_name = 'course'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        course = self.get_object()
        
        # Get all allocations for this course
        allocations = LoadAllocation.objects.filter(course=course).select_related('faculty').order_by('division', 'faculty__name')
        
        context['allocations'] = allocations
        return context


class CourseCreateView(CreateView):
    """Create view for courses."""
    model = Course
    form_class = CourseForm
    template_name = 'load_management/course_form.html'
    success_url = reverse_lazy('load_management:course_list')
    
    def form_valid(self, form):
        messages.success(self.request, f'Course "{form.instance.course_code}" created successfully.')
        return super().form_valid(form)


class CourseUpdateView(UpdateView):
    """Update view for courses."""
    model = Course
    form_class = CourseForm
    template_name = 'load_management/course_form.html'
    
    def get_success_url(self):
        return reverse_lazy('load_management:course_detail', kwargs={'pk': self.object.pk})
    
    def form_valid(self, form):
        messages.success(self.request, f'Course "{form.instance.course_code}" updated successfully.')
        return super().form_valid(form)


class CourseDeleteView(DeleteView):
    """Delete view for courses."""
    model = Course
    template_name = 'load_management/confirm_delete.html'
    success_url = reverse_lazy('load_management:course_list')
    
    def delete(self, request, *args, **kwargs):
        course = self.get_object()
        messages.success(request, f'Course "{course.course_code}" deleted successfully.')
        return super().delete(request, *args, **kwargs)


class LoadAllocationListView(ListView):
    """List view for load allocations with filtering."""
    model = LoadAllocation
    template_name = 'load_management/load_allocation.html'
    context_object_name = 'allocation_list'
    paginate_by = 20
    
    def get_queryset(self):
        queryset = LoadAllocation.objects.select_related('faculty', 'course').order_by('course__course_code', 'division')
        
        # Apply filters
        faculty_id = self.request.GET.get('faculty')
        if faculty_id:
            queryset = queryset.filter(faculty_id=faculty_id)
        
        course_id = self.request.GET.get('course')
        if course_id:
            queryset = queryset.filter(course_id=course_id)
        
        division = self.request.GET.get('division')
        if division:
            queryset = queryset.filter(division=division)
        
        faculty_number = self.request.GET.get('faculty_number')
        if faculty_number:
            queryset = queryset.filter(faculty_number=faculty_number)
        
        return queryset
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['filter_form'] = LoadAllocationFilterForm(self.request.GET)
        return context


class LoadAllocationCreateView(CreateView):
    """Create view for load allocations."""
    model = LoadAllocation
    form_class = LoadAllocationForm
    template_name = 'load_management/allocation_form.html'
    success_url = reverse_lazy('load_management:allocation_list')
    
    def form_valid(self, form):
        messages.success(self.request, 'Load allocation created successfully.')
        return super().form_valid(form)
    
    def form_invalid(self, form):
        messages.error(self.request, 'Please correct the errors below.')
        return super().form_invalid(form)


class LoadAllocationUpdateView(UpdateView):
    """Update view for load allocations."""
    model = LoadAllocation
    form_class = LoadAllocationForm
    template_name = 'load_management/allocation_form.html'
    success_url = reverse_lazy('load_management:allocation_list')
    
    def form_valid(self, form):
        messages.success(self.request, 'Load allocation updated successfully.')
        return super().form_valid(form)
    
    def form_invalid(self, form):
        messages.error(self.request, 'Please correct the errors below.')
        return super().form_invalid(form)


class LoadAllocationDeleteView(DeleteView):
    """Delete view for load allocations."""
    model = LoadAllocation
    template_name = 'load_management/confirm_delete.html'
    success_url = reverse_lazy('load_management:allocation_list')
    
    def delete(self, request, *args, **kwargs):
        allocation = self.get_object()
        messages.success(request, f'Load allocation for {allocation.course.course_code} deleted successfully.')
        return super().delete(request, *args, **kwargs)


class BulkLoadAllocationView(CreateView):
    """Bulk load allocation view for multiple divisions."""
    form_class = BulkLoadAllocationForm
    template_name = 'load_management/bulk_allocation.html'
    success_url = reverse_lazy('load_management:allocation_list')
    
    def form_valid(self, form):
        course = form.cleaned_data['course']
        divisions = form.cleaned_data['divisions']
        theory_faculty = form.cleaned_data['theory_faculty']
        practical_faculty = form.cleaned_data['practical_faculty']
        faculty_number = form.cleaned_data['faculty_number']
        
        created_count = 0
        
        for division in divisions:
            # Create theory allocation if needed
            if course.theory_credits > 0 and theory_faculty:
                theory_allocation, created = LoadAllocation.objects.get_or_create(
                    course=course,
                    faculty=theory_faculty,
                    division=division,
                    defaults={
                        'faculty_number': faculty_number,
                        'theory_allocation_percentage': 100,
                        'practical_allocation_percentage': 0,
                        'notes': f'Bulk allocation - Theory only'
                    }
                )
                if created:
                    created_count += 1
            
            # Create practical allocation if needed and different faculty
            if course.practical_credits > 0 and practical_faculty and practical_faculty != theory_faculty:
                practical_allocation, created = LoadAllocation.objects.get_or_create(
                    course=course,
                    faculty=practical_faculty,
                    division=division,
                    defaults={
                        'faculty_number': faculty_number,
                        'theory_allocation_percentage': 0,
                        'practical_allocation_percentage': 100,
                        'notes': f'Bulk allocation - Practical only'
                    }
                )
                if created:
                    created_count += 1
            
            # Create combined allocation if same faculty for both
            if (course.theory_credits > 0 and course.practical_credits > 0 and 
                theory_faculty and practical_faculty and theory_faculty == practical_faculty):
                combined_allocation, created = LoadAllocation.objects.get_or_create(
                    course=course,
                    faculty=theory_faculty,
                    division=division,
                    defaults={
                        'faculty_number': faculty_number,
                        'theory_allocation_percentage': 100,
                        'practical_allocation_percentage': 100,
                        'notes': f'Bulk allocation - Theory and Practical'
                    }
                )
                if created:
                    created_count += 1
        
        messages.success(self.request, f'Bulk allocation completed. {created_count} new allocations created.')
        return redirect(self.success_url)


# AJAX API Views
def get_faculty_load(request, faculty_id):
    """AJAX endpoint to get faculty load information."""
    try:
        faculty = get_object_or_404(Faculty, id=faculty_id)
        data = {
            'name': faculty.name,
            'max_load_hours': faculty.max_load_hours,
            'assigned_hours': faculty.total_assigned_hours,
            'load_left': faculty.load_left,
            'load_percentage': faculty.load_percentage,
        }
        return JsonResponse(data)
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=400)


def get_course_details(request, course_id):
    """AJAX endpoint to get course details."""
    try:
        course = get_object_or_404(Course, id=course_id)
        data = {
            'course_code': course.course_code,
            'course_name': course.course_name,
            'theory_credits': course.theory_credits,
            'practical_credits': course.practical_credits,
            'theory_hours_per_week': course.theory_hours_per_week,
            'practical_hours_per_week': course.practical_hours_per_week,
            'total_hours_per_week': course.total_hours_per_week,
        }
        return JsonResponse(data)
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=400)


@csrf_exempt
def calculate_load_ajax(request):
    """AJAX endpoint to calculate load for allocation."""
    if request.method != 'POST':
        return JsonResponse({'error': 'Method not allowed'}, status=405)
    
    try:
        data = json.loads(request.body)
        course_id = data.get('course_id')
        faculty_id = data.get('faculty_id')
        theory_percentage = float(data.get('theory_percentage', 0))
        practical_percentage = float(data.get('practical_percentage', 0))
        
        course = get_object_or_404(Course, id=course_id)
        faculty = get_object_or_404(Faculty, id=faculty_id)
        
        # Calculate hours
        theory_hours = (course.theory_hours_per_week * theory_percentage) / 100
        practical_hours = (course.practical_hours_per_week * practical_percentage) / 100
        total_hours = theory_hours + practical_hours
        
        # Check capacity
        available_capacity = faculty.load_left
        can_allocate = total_hours <= available_capacity
        
        response_data = {
            'theory_hours': round(theory_hours, 2),
            'practical_hours': round(practical_hours, 2),
            'total_hours': round(total_hours, 2),
            'available_capacity': round(available_capacity, 2),
            'can_allocate': can_allocate,
            'faculty_current_load': round(faculty.total_assigned_hours, 2),
            'faculty_max_load': faculty.max_load_hours,
        }
        
        return JsonResponse(response_data)
    
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=400)
