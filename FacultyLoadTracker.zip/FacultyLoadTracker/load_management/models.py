from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
from django.core.exceptions import ValidationError


class Faculty(models.Model):
    """Faculty member model with load tracking capabilities."""
    
    name = models.CharField(max_length=100, help_text="Full name of the faculty member")
    department = models.CharField(max_length=100, blank=True, null=True, help_text="Department (optional)")
    max_load_hours = models.PositiveIntegerField(
        default=20, 
        validators=[MinValueValidator(1), MaxValueValidator(40)],
        help_text="Maximum load hours per week (default: 20)"
    )
    email = models.EmailField(blank=True, null=True, help_text="Email address (optional)")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Faculty Member"
        verbose_name_plural = "Faculty Members"
        ordering = ['name']

    def __str__(self):
        return f"{self.name} ({self.department or 'No Department'})"

    @property
    def total_assigned_hours(self):
        """Calculate total hours assigned to this faculty member."""
        total = 0
        for allocation in self.loadallocation_set.all():
            total += allocation.calculated_hours
        return total

    @property
    def load_left(self):
        """Calculate remaining load capacity."""
        return max(0, self.max_load_hours - self.total_assigned_hours)

    @property
    def load_percentage(self):
        """Calculate load percentage."""
        if self.max_load_hours == 0:
            return 0
        return min(100, (self.total_assigned_hours / self.max_load_hours) * 100)

    @property
    def assigned_courses(self):
        """Get all courses assigned to this faculty."""
        return Course.objects.filter(loadallocation__faculty=self).distinct()


class Course(models.Model):
    """Course model with theory and practical credit tracking."""
    
    course_code = models.CharField(max_length=20, unique=True, help_text="Unique course code")
    course_name = models.CharField(max_length=200, help_text="Full name of the course")
    theory_credits = models.PositiveIntegerField(
        default=3,
        validators=[MinValueValidator(0), MaxValueValidator(10)],
        help_text="Theory credits (3 credits = 1 hour/week lecture)"
    )
    practical_credits = models.PositiveIntegerField(
        default=0,
        validators=[MinValueValidator(0), MaxValueValidator(10)],
        help_text="Practical credits (2 credits = 2 hours/week session)"
    )
    semester = models.CharField(max_length=50, blank=True, help_text="Semester/Year information")
    description = models.TextField(blank=True, help_text="Course description")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Course"
        verbose_name_plural = "Courses"
        ordering = ['course_code']

    def __str__(self):
        return f"{self.course_code} - {self.course_name}"

    @property
    def theory_hours_per_week(self):
        """Calculate theory hours per week (3 credits = 1 hour)."""
        return self.theory_credits / 3.0

    @property
    def practical_hours_per_week(self):
        """Calculate practical hours per week (2 credits = 2 hours)."""
        return self.practical_credits

    @property
    def total_hours_per_week(self):
        """Calculate total hours per week for this course."""
        return self.theory_hours_per_week + self.practical_hours_per_week

    @property
    def total_credits(self):
        """Calculate total credits for this course."""
        return self.theory_credits + self.practical_credits

    def clean(self):
        """Validate that course has at least some credits."""
        if self.theory_credits == 0 and self.practical_credits == 0:
            raise ValidationError("Course must have at least theory or practical credits.")


class LoadAllocation(models.Model):
    """Load allocation model for assigning courses to faculty."""
    
    DIVISION_CHOICES = [
        ('A', 'Division A'),
        ('B', 'Division B'),
        ('C', 'Division C'),
        ('D', 'Division D'),
    ]
    
    FACULTY_CHOICES = [
        (1, 'Faculty 1'),
        (2, 'Faculty 2'),
        (3, 'Faculty 3'),
        (4, 'Faculty 4'),
        (5, 'Faculty 5'),
        (6, 'Faculty 6'),
        (7, 'Faculty 7'),
    ]

    course = models.ForeignKey(Course, on_delete=models.CASCADE, help_text="Course to be allocated")
    faculty = models.ForeignKey(Faculty, on_delete=models.CASCADE, help_text="Faculty member assigned")
    division = models.CharField(max_length=1, choices=DIVISION_CHOICES, help_text="Division/Section")
    faculty_number = models.PositiveIntegerField(
        choices=FACULTY_CHOICES,
        help_text="Faculty number (1-7)"
    )
    theory_allocation_percentage = models.PositiveIntegerField(
        default=100,
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        help_text="Percentage of theory credits allocated (0-100%)"
    )
    practical_allocation_percentage = models.PositiveIntegerField(
        default=100,
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        help_text="Percentage of practical credits allocated (0-100%)"
    )
    notes = models.TextField(blank=True, help_text="Additional notes about this allocation")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Load Allocation"
        verbose_name_plural = "Load Allocations"
        unique_together = ['course', 'division', 'faculty']
        ordering = ['course__course_code', 'division']

    def __str__(self):
        return f"{self.course.course_code} - {self.division} - {self.faculty.name}"

    @property
    def calculated_hours(self):
        """Calculate total hours based on allocation percentages."""
        theory_hours = (self.course.theory_hours_per_week * self.theory_allocation_percentage) / 100
        practical_hours = (self.course.practical_hours_per_week * self.practical_allocation_percentage) / 100
        return theory_hours + practical_hours

    @property
    def theory_hours_allocated(self):
        """Calculate theory hours allocated to this faculty."""
        return (self.course.theory_hours_per_week * self.theory_allocation_percentage) / 100

    @property
    def practical_hours_allocated(self):
        """Calculate practical hours allocated to this faculty."""
        return (self.course.practical_hours_per_week * self.practical_allocation_percentage) / 100

    def clean(self):
        """Validate allocation constraints."""
        if self.theory_allocation_percentage == 0 and self.practical_allocation_percentage == 0:
            raise ValidationError("At least one allocation percentage must be greater than 0.")
        
        # Check if faculty has enough capacity
        current_load = self.faculty.total_assigned_hours
        if self.pk:  # If updating existing allocation
            # Subtract current allocation from total
            current_load -= self.calculated_hours
        
        new_load = current_load + self.calculated_hours
        if new_load > self.faculty.max_load_hours:
            raise ValidationError(
                f"This allocation would exceed {self.faculty.name}'s maximum load capacity. "
                f"Available capacity: {self.faculty.max_load_hours - current_load:.2f} hours."
            )

    def save(self, *args, **kwargs):
        """Override save to run validation."""
        self.clean()
        super().save(*args, **kwargs)
