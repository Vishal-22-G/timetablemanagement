from django.contrib import admin
from django.db.models import Sum
from django.utils.html import format_html
from .models import Faculty, Course, LoadAllocation


@admin.register(Faculty)
class FacultyAdmin(admin.ModelAdmin):
    """Admin interface for Faculty model."""
    
    list_display = [
        'name', 'department', 'max_load_hours', 
        'get_assigned_hours', 'get_load_left', 'get_load_percentage'
    ]
    list_filter = ['department', 'created_at']
    search_fields = ['name', 'department', 'email']
    readonly_fields = ['created_at', 'updated_at', 'get_assigned_courses']
    
    fieldsets = (
        ('Basic Information', {
            'fields': ('name', 'department', 'email')
        }),
        ('Load Configuration', {
            'fields': ('max_load_hours',)
        }),
        ('System Information', {
            'fields': ('created_at', 'updated_at', 'get_assigned_courses'),
            'classes': ('collapse',)
        }),
    )

    def get_assigned_hours(self, obj):
        """Display assigned hours with color coding."""
        hours = obj.total_assigned_hours
        percentage = obj.load_percentage
        
        if percentage >= 100:
            color = '#dc3545'  # Red for overloaded
        elif percentage >= 80:
            color = '#fd7e14'  # Orange for high load
        else:
            color = '#28a745'  # Green for normal load
            
        return format_html(
            '<span style="color: {}; font-weight: bold;">{:.2f} hrs</span>',
            color, hours
        )
    get_assigned_hours.short_description = 'Assigned Hours'

    def get_load_left(self, obj):
        """Display remaining load capacity."""
        load_left = obj.load_left
        color = '#28a745' if load_left > 0 else '#dc3545'
        return format_html(
            '<span style="color: {}; font-weight: bold;">{:.2f} hrs</span>',
            color, load_left
        )
    get_load_left.short_description = 'Load Left'

    def get_load_percentage(self, obj):
        """Display load percentage with progress bar."""
        percentage = obj.load_percentage
        if percentage >= 100:
            color = 'danger'
        elif percentage >= 80:
            color = 'warning'
        else:
            color = 'success'
            
        return format_html(
            '<div class="progress" style="width: 100px;">'
            '<div class="progress-bar bg-{}" style="width: {}%">{:.1f}%</div>'
            '</div>',
            color, min(100, percentage), percentage
        )
    get_load_percentage.short_description = 'Load %'

    def get_assigned_courses(self, obj):
        """Display assigned courses."""
        courses = obj.assigned_courses.all()
        if courses:
            return ', '.join([course.course_code for course in courses])
        return 'No courses assigned'
    get_assigned_courses.short_description = 'Assigned Courses'


@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    """Admin interface for Course model."""
    
    list_display = [
        'course_code', 'course_name', 'theory_credits', 
        'practical_credits', 'get_total_hours', 'semester'
    ]
    list_filter = ['semester', 'theory_credits', 'practical_credits']
    search_fields = ['course_code', 'course_name']
    readonly_fields = ['created_at', 'updated_at']
    
    fieldsets = (
        ('Course Information', {
            'fields': ('course_code', 'course_name', 'semester', 'description')
        }),
        ('Credit Structure', {
            'fields': ('theory_credits', 'practical_credits'),
            'description': 'Theory: 3 credits = 1 hour/week | Practical: 2 credits = 2 hours/week'
        }),
        ('System Information', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )

    def get_total_hours(self, obj):
        """Display total hours per week."""
        return f"{obj.total_hours_per_week:.2f} hrs/week"
    get_total_hours.short_description = 'Total Hours/Week'


class LoadAllocationInline(admin.TabularInline):
    """Inline admin for Load Allocation."""
    model = LoadAllocation
    extra = 0
    readonly_fields = ['calculated_hours']
    
    def calculated_hours(self, obj):
        if obj.pk:
            return f"{obj.calculated_hours:.2f} hrs"
        return "0 hrs"
    calculated_hours.short_description = 'Calculated Hours'


@admin.register(LoadAllocation)
class LoadAllocationAdmin(admin.ModelAdmin):
    """Admin interface for Load Allocation model."""
    
    list_display = [
        'course', 'faculty', 'division', 'faculty_number',
        'get_theory_allocation', 'get_practical_allocation', 'get_calculated_hours'
    ]
    list_filter = [
        'division', 'faculty_number', 'course__semester', 
        'faculty__department', 'created_at'
    ]
    search_fields = [
        'course__course_code', 'course__course_name', 
        'faculty__name', 'faculty__department'
    ]
    readonly_fields = ['calculated_hours', 'created_at', 'updated_at']
    
    fieldsets = (
        ('Allocation Details', {
            'fields': ('course', 'faculty', 'division', 'faculty_number')
        }),
        ('Load Distribution', {
            'fields': (
                'theory_allocation_percentage', 
                'practical_allocation_percentage',
                'calculated_hours'
            ),
            'description': 'Specify what percentage of the course load this faculty will handle'
        }),
        ('Additional Information', {
            'fields': ('notes',)
        }),
        ('System Information', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )

    def get_theory_allocation(self, obj):
        """Display theory allocation percentage."""
        if obj.course.theory_credits > 0:
            return f"{obj.theory_allocation_percentage}% ({obj.theory_hours_allocated:.2f} hrs)"
        return "N/A"
    get_theory_allocation.short_description = 'Theory Allocation'

    def get_practical_allocation(self, obj):
        """Display practical allocation percentage."""
        if obj.course.practical_credits > 0:
            return f"{obj.practical_allocation_percentage}% ({obj.practical_hours_allocated:.2f} hrs)"
        return "N/A"
    get_practical_allocation.short_description = 'Practical Allocation'

    def get_calculated_hours(self, obj):
        """Display total calculated hours."""
        return f"{obj.calculated_hours:.2f} hrs"
    get_calculated_hours.short_description = 'Total Hours'

    def formfield_for_foreignkey(self, db_field, request, **kwargs):
        """Customize foreign key fields."""
        if db_field.name == "faculty":
            # Order faculty by name for easier selection
            kwargs["queryset"] = Faculty.objects.order_by('name')
        elif db_field.name == "course":
            # Order courses by course code
            kwargs["queryset"] = Course.objects.order_by('course_code')
        return super().formfield_for_foreignkey(db_field, request, **kwargs)


# Customize admin site headers
admin.site.site_header = "Faculty Load Management System"
admin.site.site_title = "Faculty Load Management"
admin.site.index_title = "Welcome to Faculty Load Management System"
