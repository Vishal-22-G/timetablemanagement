from django.urls import path
from . import views

app_name = 'load_management'

urlpatterns = [
    # Dashboard
    path('', views.DashboardView.as_view(), name='dashboard'),
    
    # Faculty URLs
    path('faculty/', views.FacultyListView.as_view(), name='faculty_list'),
    path('faculty/create/', views.FacultyCreateView.as_view(), name='faculty_create'),
    path('faculty/<int:pk>/', views.FacultyDetailView.as_view(), name='faculty_detail'),
    path('faculty/<int:pk>/edit/', views.FacultyUpdateView.as_view(), name='faculty_update'),
    path('faculty/<int:pk>/delete/', views.FacultyDeleteView.as_view(), name='faculty_delete'),
    
    # Course URLs
    path('courses/', views.CourseListView.as_view(), name='course_list'),
    path('courses/create/', views.CourseCreateView.as_view(), name='course_create'),
    path('courses/<int:pk>/', views.CourseDetailView.as_view(), name='course_detail'),
    path('courses/<int:pk>/edit/', views.CourseUpdateView.as_view(), name='course_update'),
    path('courses/<int:pk>/delete/', views.CourseDeleteView.as_view(), name='course_delete'),
    
    # Load Allocation URLs
    path('allocations/', views.LoadAllocationListView.as_view(), name='allocation_list'),
    path('allocations/create/', views.LoadAllocationCreateView.as_view(), name='allocation_create'),
    path('allocations/<int:pk>/edit/', views.LoadAllocationUpdateView.as_view(), name='allocation_update'),
    path('allocations/<int:pk>/delete/', views.LoadAllocationDeleteView.as_view(), name='allocation_delete'),
    path('allocations/bulk/', views.BulkLoadAllocationView.as_view(), name='bulk_allocation'),
    
    # API endpoints for AJAX calls
    path('api/faculty/<int:faculty_id>/load/', views.get_faculty_load, name='api_faculty_load'),
    path('api/course/<int:course_id>/details/', views.get_course_details, name='api_course_details'),
    path('api/calculate-load/', views.calculate_load_ajax, name='api_calculate_load'),
]
