from django import forms
from django.core.exceptions import ValidationError
from .models import Faculty, Course, LoadAllocation


class FacultyForm(forms.ModelForm):
    """Form for creating and updating faculty members."""
    
    class Meta:
        model = Faculty
        fields = ['name', 'department', 'email', 'max_load_hours']
        widgets = {
            'name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter faculty full name'
            }),
            'department': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter department name (optional)'
            }),
            'email': forms.EmailInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter email address (optional)'
            }),
            'max_load_hours': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': '1',
                'max': '40',
                'placeholder': 'Maximum load hours per week'
            }),
        }
        help_texts = {
            'max_load_hours': 'Maximum teaching load hours per week (typically 15-25 hours)',
        }

    def clean_name(self):
        """Validate faculty name."""
        name = self.cleaned_data.get('name')
        if name:
            name = name.strip()
            if len(name) < 2:
                raise ValidationError("Faculty name must be at least 2 characters long.")
        return name


class CourseForm(forms.ModelForm):
    """Form for creating and updating courses."""
    
    class Meta:
        model = Course
        fields = ['course_code', 'course_name', 'theory_credits', 'practical_credits', 'semester', 'description']
        widgets = {
            'course_code': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'e.g., CS101, MATH201',
                'style': 'text-transform: uppercase;'
            }),
            'course_name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter full course name'
            }),
            'theory_credits': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': '0',
                'max': '10',
                'placeholder': '3 credits = 1 hour/week'
            }),
            'practical_credits': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': '0',
                'max': '10',
                'placeholder': '2 credits = 2 hours/week'
            }),
            'semester': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'e.g., Fall 2025, Spring 2025'
            }),
            'description': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': 'Course description (optional)'
            }),
        }

    def clean_course_code(self):
        """Validate and format course code."""
        code = self.cleaned_data.get('course_code')
        if code:
            code = code.upper().strip()
            if len(code) < 3:
                raise ValidationError("Course code must be at least 3 characters long.")
        return code

    def clean(self):
        """Validate that course has at least some credits."""
        cleaned_data = super().clean()
        theory_credits = cleaned_data.get('theory_credits', 0)
        practical_credits = cleaned_data.get('practical_credits', 0)
        
        if theory_credits == 0 and practical_credits == 0:
            raise ValidationError("Course must have at least theory or practical credits.")
        
        return cleaned_data


class LoadAllocationForm(forms.ModelForm):
    """Form for creating and updating load allocations."""
    
    class Meta:
        model = LoadAllocation
        fields = [
            'course', 'faculty', 'division', 'faculty_number',
            'theory_allocation_percentage', 'practical_allocation_percentage', 'notes'
        ]
        widgets = {
            'course': forms.Select(attrs={
                'class': 'form-select',
                'id': 'course-select'
            }),
            'faculty': forms.Select(attrs={
                'class': 'form-select',
                'id': 'faculty-select'
            }),
            'division': forms.Select(attrs={
                'class': 'form-select'
            }),
            'faculty_number': forms.Select(attrs={
                'class': 'form-select'
            }),
            'theory_allocation_percentage': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': '0',
                'max': '100',
                'id': 'theory-percentage'
            }),
            'practical_allocation_percentage': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': '0',
                'max': '100',
                'id': 'practical-percentage'
            }),
            'notes': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': 'Additional notes about this allocation'
            }),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Order querysets for better user experience
        self.fields['course'].queryset = Course.objects.order_by('course_code')
        self.fields['faculty'].queryset = Faculty.objects.order_by('name')

    def clean(self):
        """Validate allocation constraints."""
        cleaned_data = super().clean()
        theory_percentage = cleaned_data.get('theory_allocation_percentage', 0)
        practical_percentage = cleaned_data.get('practical_allocation_percentage', 0)
        faculty = cleaned_data.get('faculty')
        course = cleaned_data.get('course')
        
        # Check that at least one allocation percentage is set
        if theory_percentage == 0 and practical_percentage == 0:
            raise ValidationError("At least one allocation percentage must be greater than 0.")
        
        # Check faculty capacity if all required fields are present
        if faculty and course:
            # Calculate hours for this allocation
            theory_hours = (course.theory_hours_per_week * theory_percentage) / 100
            practical_hours = (course.practical_hours_per_week * practical_percentage) / 100
            total_hours = theory_hours + practical_hours
            
            # Check current faculty load
            current_load = faculty.total_assigned_hours
            if self.instance.pk:  # If updating existing allocation
                current_load -= self.instance.calculated_hours
            
            new_total_load = current_load + total_hours
            if new_total_load > faculty.max_load_hours:
                raise ValidationError(
                    f"This allocation would exceed {faculty.name}'s maximum load capacity. "
                    f"Current load: {current_load:.2f} hrs, "
                    f"New allocation: {total_hours:.2f} hrs, "
                    f"Maximum capacity: {faculty.max_load_hours} hrs. "
                    f"Available capacity: {faculty.max_load_hours - current_load:.2f} hrs."
                )
        
        return cleaned_data


class LoadAllocationFilterForm(forms.Form):
    """Form for filtering load allocations."""
    
    faculty = forms.ModelChoiceField(
        queryset=Faculty.objects.order_by('name'),
        required=False,
        empty_label="All Faculty",
        widget=forms.Select(attrs={'class': 'form-select'})
    )
    
    course = forms.ModelChoiceField(
        queryset=Course.objects.order_by('course_code'),
        required=False,
        empty_label="All Courses",
        widget=forms.Select(attrs={'class': 'form-select'})
    )
    
    division = forms.ChoiceField(
        choices=[('', 'All Divisions')] + LoadAllocation.DIVISION_CHOICES,
        required=False,
        widget=forms.Select(attrs={'class': 'form-select'})
    )
    
    faculty_number = forms.ChoiceField(
        choices=[('', 'All Faculty Numbers')] + LoadAllocation.FACULTY_CHOICES,
        required=False,
        widget=forms.Select(attrs={'class': 'form-select'})
    )


class BulkLoadAllocationForm(forms.Form):
    """Form for bulk load allocation across multiple divisions."""
    
    course = forms.ModelChoiceField(
        queryset=Course.objects.order_by('course_code'),
        widget=forms.Select(attrs={'class': 'form-select'})
    )
    
    divisions = forms.MultipleChoiceField(
        choices=LoadAllocation.DIVISION_CHOICES,
        widget=forms.CheckboxSelectMultiple(attrs={'class': 'form-check-input'})
    )
    
    theory_faculty = forms.ModelChoiceField(
        queryset=Faculty.objects.order_by('name'),
        required=False,
        empty_label="Select Faculty for Theory",
        widget=forms.Select(attrs={'class': 'form-select'})
    )
    
    practical_faculty = forms.ModelChoiceField(
        queryset=Faculty.objects.order_by('name'),
        required=False,
        empty_label="Select Faculty for Practical",
        widget=forms.Select(attrs={'class': 'form-select'})
    )
    
    faculty_number = forms.ChoiceField(
        choices=LoadAllocation.FACULTY_CHOICES,
        widget=forms.Select(attrs={'class': 'form-select'})
    )

    def clean(self):
        """Validate bulk allocation."""
        cleaned_data = super().clean()
        course = cleaned_data.get('course')
        theory_faculty = cleaned_data.get('theory_faculty')
        practical_faculty = cleaned_data.get('practical_faculty')
        
        if not course:
            raise ValidationError("Course selection is required.")
        
        if course.theory_credits > 0 and not theory_faculty:
            raise ValidationError("Theory faculty must be selected for courses with theory credits.")
        
        if course.practical_credits > 0 and not practical_faculty:
            raise ValidationError("Practical faculty must be selected for courses with practical credits.")
        
        return cleaned_data
